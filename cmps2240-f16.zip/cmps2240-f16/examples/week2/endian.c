/* endian.c
 * purpose:  demonstrate little-endianness in x86  
 */

int NUM;
int main()
{
  NUM = 10531008;   /* this is 0xA0B0C0 */
  return 0;
}
