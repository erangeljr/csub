/* filename: tiny.c
 *   purpose:  demonstrate creating a tiny executable 
 *
 * USAGE: 
 * $ gcc -S tiny.c
 * $ as -o tiny.o tiny.s
 * $ ld -o tiny tiny.o -lc
 * $ ./tiny
 *
*/
int main()
{
   int x = 5;
   x = x + 1;
   return 0;
}
