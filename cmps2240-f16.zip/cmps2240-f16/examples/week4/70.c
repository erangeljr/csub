/* implementation of phase 70 in C */
#include <stdio.h>

int main(int argc , char ** argv)
{
  printf("%s\n",argv[1]);   /* in MIPS argv is into $a0 */
  return 0;
}
