/* hw04.c 
   some C examples for homework 4*/
int main() {
  int stuff[10] = {0};
  return 0;
}
