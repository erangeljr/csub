
#include <stdlib.h>
#include <stdio.h>

int fac(int n)
{
  if ( n == 0 )
    return 1;
  return n * fac(n-1); 
}

int main( int argc, char *argv[])
{ 
  int num;
  if ( argc == 2 )
     num = atoi(argv[1]);
  else 
     num = 7;

  printf("5! = %d\n",fac(num));
  return 0;
} 
