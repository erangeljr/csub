#define TWELVE 12
int main () {
  write(1,"hello world\n",TWELVE);
  return 0;
}
