/* Dog.java
 * used in Param-passing.java  
 */

public class Dog
{
   private String name;

   public Dog ( String s)
   { name = s; }

   public void setName (String s)
   { name = s; }

   public String getName ()
   { return name; }
}
