
int main()
{
  double myInt = 99;
  return 0;
}
