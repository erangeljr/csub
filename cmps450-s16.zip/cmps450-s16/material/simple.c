/*filename: simple.c */

char strLiteral[10] = "hello";
char charLit = 'a';
double floatConstant  = 5.7;
const int intConstant  = 5;

int main(void) {
   return 0;
}
