int main()
{

 int 5a=5;
 return 0;
}
