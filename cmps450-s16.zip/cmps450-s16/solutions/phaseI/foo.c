#include <stdlib.h>

int main(){

  double f = 5.;
  f = 7e3;
  f = .5;
  f = .05e-5;
  f = 754.e2;  
  return 0;
}
