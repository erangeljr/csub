#define ITYPE 1
#define FTYPE 2
#define CTYPE 3

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

