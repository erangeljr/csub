int main () {
 while (a == 100)
 {
   a = 10;
   a = 99;
 }
 return 0;
}
