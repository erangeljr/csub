/* constants.c
 * demonstrates how the C compiler handles constants
 */

int myNum = 55;
char myStr[10] = "hello";

int main () {
   int myNum2 = 99;
   double myFloat = 7.7;
   return 0;
}
