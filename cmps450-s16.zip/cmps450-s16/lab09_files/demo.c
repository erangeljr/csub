int main () {
 if (a == 77)
   a = 88;
 else
   a = 99;
 return 0;
}
