int i;
float f;
int main ()
{ int i = 7;
  i = 5;
  float f = 3.2;
}
