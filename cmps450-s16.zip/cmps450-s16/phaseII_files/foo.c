void foo(){
}
