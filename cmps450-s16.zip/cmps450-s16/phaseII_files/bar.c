int a = 10 + 15;
int x = 34 + a;
void foo() {
 return null;
}

